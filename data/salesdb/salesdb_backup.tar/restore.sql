--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.6 (Debian 17.6-1.pgdg13+1)
-- Dumped by pg_dump version 17.6 (Debian 17.6-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE salesdb;
--
-- Name: salesdb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE salesdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE salesdb OWNER TO postgres;

\unrestrict (null)
\connect salesdb
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: companies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.companies (
    company_id bigint NOT NULL,
    company_name character varying(127) NOT NULL,
    ticker character varying(15) NOT NULL,
    sector_id bigint,
    industry_id bigint,
    market_segments_id bigint,
    number_of_employees bigint DEFAULT 0,
    market_cap money DEFAULT 0.0,
    inserted_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    inserted_by character varying(127) DEFAULT 'system'::character varying,
    is_deleted boolean DEFAULT false
);


ALTER TABLE public.companies OWNER TO postgres;

--
-- Name: companies_company_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.companies_company_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.companies_company_id_seq OWNER TO postgres;

--
-- Name: companies_company_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.companies_company_id_seq OWNED BY public.companies.company_id;


--
-- Name: employee_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_roles (
    employee_roles_id bigint NOT NULL,
    role_name character varying(127) NOT NULL,
    inserted_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    inserted_by character varying(127) DEFAULT 'system'::character varying,
    is_deleted boolean DEFAULT false
);


ALTER TABLE public.employee_roles OWNER TO postgres;

--
-- Name: employee_roles_employee_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_roles_employee_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employee_roles_employee_roles_id_seq OWNER TO postgres;

--
-- Name: employee_roles_employee_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_roles_employee_roles_id_seq OWNED BY public.employee_roles.employee_roles_id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    employee_id bigint NOT NULL,
    employee_roles_id bigint NOT NULL,
    name_last character varying(127) NOT NULL,
    name_first character varying(127) NOT NULL,
    email character varying(4096) NOT NULL,
    phone_cell character varying(64),
    inserted_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    inserted_by character varying(127) DEFAULT 'system'::character varying NOT NULL,
    is_deleted boolean DEFAULT false,
    region_id bigint DEFAULT 2
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- Name: employees_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employees_employee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employees_employee_id_seq OWNER TO postgres;

--
-- Name: employees_employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employees_employee_id_seq OWNED BY public.employees.employee_id;


--
-- Name: employees_employee_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employees_employee_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employees_employee_roles_id_seq OWNER TO postgres;

--
-- Name: employees_employee_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employees_employee_roles_id_seq OWNED BY public.employees.employee_roles_id;


--
-- Name: incentive_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.incentive_groups (
    incentive_groups_id bigint NOT NULL,
    incentive_groups_name character varying(127) NOT NULL,
    inserted_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    inserted_by character varying(127) DEFAULT 'system'::character varying,
    is_deleted boolean DEFAULT false
);


ALTER TABLE public.incentive_groups OWNER TO postgres;

--
-- Name: incentive_groups_incentive_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.incentive_groups_incentive_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.incentive_groups_incentive_groups_id_seq OWNER TO postgres;

--
-- Name: incentive_groups_incentive_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.incentive_groups_incentive_groups_id_seq OWNED BY public.incentive_groups.incentive_groups_id;


--
-- Name: incentives; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.incentives (
    incentive_id bigint NOT NULL,
    incentive_name character varying(2048) NOT NULL,
    trip_value numeric DEFAULT 0,
    discount_value numeric DEFAULT 0,
    inserted_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    inserted_by character varying(127) DEFAULT 'system'::character varying,
    is_deleted boolean DEFAULT false,
    incentive_groups_id bigint NOT NULL
);


ALTER TABLE public.incentives OWNER TO postgres;

--
-- Name: incentives_incentive_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.incentives_incentive_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.incentives_incentive_id_seq OWNER TO postgres;

--
-- Name: incentives_incentive_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.incentives_incentive_id_seq OWNED BY public.incentives.incentive_id;


--
-- Name: industries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.industries (
    industry_id bigint NOT NULL,
    industry_name character varying(127) NOT NULL,
    inserted_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    inserted_by character varying(127) DEFAULT 'system'::character varying,
    is_deleted boolean DEFAULT false
);


ALTER TABLE public.industries OWNER TO postgres;

--
-- Name: industries_industry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.industries_industry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.industries_industry_id_seq OWNER TO postgres;

--
-- Name: industries_industry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.industries_industry_id_seq OWNED BY public.industries.industry_id;


--
-- Name: market_segments_market_segments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.market_segments_market_segments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.market_segments_market_segments_id_seq OWNER TO postgres;

--
-- Name: market_segments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.market_segments (
    market_segments_id bigint DEFAULT nextval('public.market_segments_market_segments_id_seq'::regclass) NOT NULL,
    market_segments_name character varying(127) NOT NULL,
    inserted_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    inserted_by character varying(127) DEFAULT 'system'::character varying,
    is_deleted boolean DEFAULT false
);


ALTER TABLE public.market_segments OWNER TO postgres;

--
-- Name: product_types_product_types_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_types_product_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_types_product_types_id_seq OWNER TO postgres;

--
-- Name: product_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_types (
    product_types_id bigint DEFAULT nextval('public.product_types_product_types_id_seq'::regclass) NOT NULL,
    product_types_name character varying(127) NOT NULL,
    inserted_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    inserted_by character varying(127) DEFAULT 'system'::character varying,
    is_deleted boolean DEFAULT false
);


ALTER TABLE public.product_types OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    products_id bigint NOT NULL,
    product_name character varying(127) NOT NULL,
    product_types_id bigint NOT NULL,
    product_description text,
    inserted_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    inserted_by character varying(127) DEFAULT 'system'::character varying,
    is_deleted boolean DEFAULT false
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: products_products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_products_id_seq OWNER TO postgres;

--
-- Name: products_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_products_id_seq OWNED BY public.products.products_id;


--
-- Name: regions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.regions (
    regions_id bigint NOT NULL,
    regions_name character varying(127) NOT NULL,
    inserted_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    inserted_by character varying(127) DEFAULT 'system'::character varying,
    is_deleted boolean DEFAULT false
);


ALTER TABLE public.regions OWNER TO postgres;

--
-- Name: regions_regions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.regions_regions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.regions_regions_id_seq OWNER TO postgres;

--
-- Name: regions_regions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.regions_regions_id_seq OWNED BY public.regions.regions_id;


--
-- Name: sectors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sectors (
    sector_id bigint NOT NULL,
    sector_name character varying(127) NOT NULL,
    inserted_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    inserted_by character varying(127) DEFAULT 'system'::character varying,
    is_deleted boolean DEFAULT false
);


ALTER TABLE public.sectors OWNER TO postgres;

--
-- Name: sectors_sector_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sectors_sector_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sectors_sector_id_seq OWNER TO postgres;

--
-- Name: sectors_sector_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sectors_sector_id_seq OWNED BY public.sectors.sector_id;


--
-- Name: vw_companies; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_companies AS
 SELECT comp.company_id,
    comp.company_name,
    comp.ticker,
    sect.sector_name,
    indu.industry_name,
    mark.market_segments_name,
    comp.number_of_employees,
    comp.market_cap
   FROM (((public.companies comp
     JOIN public.sectors sect ON ((comp.sector_id = sect.sector_id)))
     JOIN public.market_segments mark ON ((comp.market_segments_id = mark.market_segments_id)))
     JOIN public.industries indu ON ((comp.industry_id = indu.industry_id)))
  WHERE (comp.is_deleted = false);


ALTER VIEW public.vw_companies OWNER TO postgres;

--
-- Name: vw_employees; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_employees AS
 SELECT reg.regions_name,
    rol.role_name,
    emp.name_first,
    emp.name_last,
    emp.email,
    emp.phone_cell
   FROM ((public.employees emp
     JOIN public.regions reg ON ((emp.region_id = reg.regions_id)))
     JOIN public.employee_roles rol ON ((emp.employee_roles_id = rol.employee_roles_id)))
  WHERE (emp.is_deleted = false);


ALTER VIEW public.vw_employees OWNER TO postgres;

--
-- Name: vw_products; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_products AS
 SELECT pt.product_types_name,
    prod.products_id,
    prod.product_name,
    prod.product_description
   FROM (public.products prod
     JOIN public.product_types pt ON ((prod.product_types_id = pt.product_types_id)))
  WHERE (prod.is_deleted = false);


ALTER VIEW public.vw_products OWNER TO postgres;

--
-- Name: companies company_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies ALTER COLUMN company_id SET DEFAULT nextval('public.companies_company_id_seq'::regclass);


--
-- Name: employee_roles employee_roles_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_roles ALTER COLUMN employee_roles_id SET DEFAULT nextval('public.employee_roles_employee_roles_id_seq'::regclass);


--
-- Name: employees employee_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees ALTER COLUMN employee_id SET DEFAULT nextval('public.employees_employee_id_seq'::regclass);


--
-- Name: employees employee_roles_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees ALTER COLUMN employee_roles_id SET DEFAULT nextval('public.employees_employee_roles_id_seq'::regclass);


--
-- Name: incentive_groups incentive_groups_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incentive_groups ALTER COLUMN incentive_groups_id SET DEFAULT nextval('public.incentive_groups_incentive_groups_id_seq'::regclass);


--
-- Name: incentives incentive_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incentives ALTER COLUMN incentive_id SET DEFAULT nextval('public.incentives_incentive_id_seq'::regclass);


--
-- Name: industries industry_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.industries ALTER COLUMN industry_id SET DEFAULT nextval('public.industries_industry_id_seq'::regclass);


--
-- Name: products products_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN products_id SET DEFAULT nextval('public.products_products_id_seq'::regclass);


--
-- Name: regions regions_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.regions ALTER COLUMN regions_id SET DEFAULT nextval('public.regions_regions_id_seq'::regclass);


--
-- Name: sectors sector_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sectors ALTER COLUMN sector_id SET DEFAULT nextval('public.sectors_sector_id_seq'::regclass);


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.companies (company_id, company_name, ticker, sector_id, industry_id, market_segments_id, number_of_employees, market_cap, inserted_on, inserted_by, is_deleted) FROM stdin;
\.
COPY public.companies (company_id, company_name, ticker, sector_id, industry_id, market_segments_id, number_of_employees, market_cap, inserted_on, inserted_by, is_deleted) FROM '$$PATH$$/3564.dat';

--
-- Data for Name: employee_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_roles (employee_roles_id, role_name, inserted_on, inserted_by, is_deleted) FROM stdin;
\.
COPY public.employee_roles (employee_roles_id, role_name, inserted_on, inserted_by, is_deleted) FROM '$$PATH$$/3566.dat';

--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employees (employee_id, employee_roles_id, name_last, name_first, email, phone_cell, inserted_on, inserted_by, is_deleted, region_id) FROM stdin;
\.
COPY public.employees (employee_id, employee_roles_id, name_last, name_first, email, phone_cell, inserted_on, inserted_by, is_deleted, region_id) FROM '$$PATH$$/3568.dat';

--
-- Data for Name: incentive_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.incentive_groups (incentive_groups_id, incentive_groups_name, inserted_on, inserted_by, is_deleted) FROM stdin;
\.
COPY public.incentive_groups (incentive_groups_id, incentive_groups_name, inserted_on, inserted_by, is_deleted) FROM '$$PATH$$/3571.dat';

--
-- Data for Name: incentives; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.incentives (incentive_id, incentive_name, trip_value, discount_value, inserted_on, inserted_by, is_deleted, incentive_groups_id) FROM stdin;
\.
COPY public.incentives (incentive_id, incentive_name, trip_value, discount_value, inserted_on, inserted_by, is_deleted, incentive_groups_id) FROM '$$PATH$$/3573.dat';

--
-- Data for Name: industries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.industries (industry_id, industry_name, inserted_on, inserted_by, is_deleted) FROM stdin;
\.
COPY public.industries (industry_id, industry_name, inserted_on, inserted_by, is_deleted) FROM '$$PATH$$/3575.dat';

--
-- Data for Name: market_segments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.market_segments (market_segments_id, market_segments_name, inserted_on, inserted_by, is_deleted) FROM stdin;
\.
COPY public.market_segments (market_segments_id, market_segments_name, inserted_on, inserted_by, is_deleted) FROM '$$PATH$$/3578.dat';

--
-- Data for Name: product_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_types (product_types_id, product_types_name, inserted_on, inserted_by, is_deleted) FROM stdin;
\.
COPY public.product_types (product_types_id, product_types_name, inserted_on, inserted_by, is_deleted) FROM '$$PATH$$/3580.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (products_id, product_name, product_types_id, product_description, inserted_on, inserted_by, is_deleted) FROM stdin;
\.
COPY public.products (products_id, product_name, product_types_id, product_description, inserted_on, inserted_by, is_deleted) FROM '$$PATH$$/3581.dat';

--
-- Data for Name: regions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.regions (regions_id, regions_name, inserted_on, inserted_by, is_deleted) FROM stdin;
\.
COPY public.regions (regions_id, regions_name, inserted_on, inserted_by, is_deleted) FROM '$$PATH$$/3583.dat';

--
-- Data for Name: sectors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sectors (sector_id, sector_name, inserted_on, inserted_by, is_deleted) FROM stdin;
\.
COPY public.sectors (sector_id, sector_name, inserted_on, inserted_by, is_deleted) FROM '$$PATH$$/3585.dat';

--
-- Name: companies_company_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.companies_company_id_seq', 200, true);


--
-- Name: employee_roles_employee_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_roles_employee_roles_id_seq', 7, true);


--
-- Name: employees_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employees_employee_id_seq', 133, true);


--
-- Name: employees_employee_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employees_employee_roles_id_seq', 1, false);


--
-- Name: incentive_groups_incentive_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.incentive_groups_incentive_groups_id_seq', 3, true);


--
-- Name: incentives_incentive_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.incentives_incentive_id_seq', 3, true);


--
-- Name: industries_industry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.industries_industry_id_seq', 22, true);


--
-- Name: market_segments_market_segments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.market_segments_market_segments_id_seq', 4, true);


--
-- Name: product_types_product_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_types_product_types_id_seq', 6, true);


--
-- Name: products_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_products_id_seq', 28, true);


--
-- Name: regions_regions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.regions_regions_id_seq', 5, true);


--
-- Name: sectors_sector_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sectors_sector_id_seq', 76, true);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (company_id);


--
-- Name: employee_roles employee_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_roles
    ADD CONSTRAINT employee_roles_pkey PRIMARY KEY (employee_roles_id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (employee_id);


--
-- Name: incentive_groups incentive_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incentive_groups
    ADD CONSTRAINT incentive_groups_pkey PRIMARY KEY (incentive_groups_id);


--
-- Name: incentives incentives_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incentives
    ADD CONSTRAINT incentives_pkey PRIMARY KEY (incentive_id);


--
-- Name: industries industries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.industries
    ADD CONSTRAINT industries_pkey PRIMARY KEY (industry_id);


--
-- Name: market_segments market_segments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.market_segments
    ADD CONSTRAINT market_segments_pkey PRIMARY KEY (market_segments_id);


--
-- Name: product_types product_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_types
    ADD CONSTRAINT product_types_pkey PRIMARY KEY (product_types_id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (products_id);


--
-- Name: regions regions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_pkey PRIMARY KEY (regions_id);


--
-- Name: sectors sectors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sectors
    ADD CONSTRAINT sectors_pkey PRIMARY KEY (sector_id);


--
-- Name: employees employees_employee_roles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_employee_roles_id_fkey FOREIGN KEY (employee_roles_id) REFERENCES public.employee_roles(employee_roles_id) NOT VALID;


--
-- Name: incentives incentive_groups_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.incentives
    ADD CONSTRAINT incentive_groups_fk FOREIGN KEY (incentive_groups_id) REFERENCES public.incentive_groups(incentive_groups_id) NOT VALID;


--
-- Name: companies industry_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT industry_fk FOREIGN KEY (industry_id) REFERENCES public.industries(industry_id) NOT VALID;


--
-- Name: companies market_segments_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT market_segments_fk FOREIGN KEY (market_segments_id) REFERENCES public.market_segments(market_segments_id) NOT VALID;


--
-- Name: products product_types; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT product_types FOREIGN KEY (product_types_id) REFERENCES public.product_types(product_types_id);


--
-- Name: employees region_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT region_fk FOREIGN KEY (region_id) REFERENCES public.regions(regions_id) NOT VALID;


--
-- Name: companies sector_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT sector_fk FOREIGN KEY (sector_id) REFERENCES public.sectors(sector_id) NOT VALID;


--
-- PostgreSQL database dump complete
--

